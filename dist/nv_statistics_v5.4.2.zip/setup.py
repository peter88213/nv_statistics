#!/usr/bin/python3
import setuplib

setuplib.main(False)
