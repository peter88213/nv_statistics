"""Project statistics view plugin for novelibre.

Requires Python 3.7+
Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/nv_statistics
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from pathlib import Path
from tkinter import ttk
import webbrowser

import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_statistics',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from abc import ABC, abstractmethod



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

from pathlib import Path

import tkinter as tk


def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True

from tkinter import ttk

from abc import ABC, abstractmethod


class Observer(ABC):

    @abstractmethod
    def refresh(self):
        pass
import textwrap



try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MAJOR_MARKER = _('Major Character')
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
TIMETABLE_SUFFIX = '_tt_tmp'
XREF_SUFFIX = '_xref'

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    None,
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done')
]

SCENE = ['-', 'A', 'R', 'x']


class Error(Exception):
    pass


class Notification(Error):
    pass


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr

from abc import ABC, abstractmethod

from tkinter import ttk

import platform



class GenericKeys:

    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')


class GenericMouse:
    pass



class MacKeys(GenericKeys):

    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')



class MacMouse(GenericMouse):
    pass


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')



class WindowsMouse(GenericMouse):
    pass



class LinuxMouse(GenericMouse):

    BACK_SCROLL = '<Button-4>'
    FORWARD_SCROLL = '<Button-5>'


if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = WindowsMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = LinuxMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse()



class ScrollFrame(ttk.Frame):

    def __init__(self, parent, *args, **kw):

        ttk.Frame.__init__(self, parent, *args, **kw)

        scrollY = ttk.Scrollbar(
            self,
            orient='vertical',
            command=self.yview,
        )
        scrollY.pack(fill='y', side='right', expand=False)

        self.canvas = tk.Canvas(
            self,
            borderwidth=0,
            highlightthickness=0
            )
        self.canvas.configure(yscrollcommand=scrollY.set)
        self.canvas.pack(
            anchor='n',
            fill='both',
            expand=True
            )
        self.canvas.xview_moveto(0)
        self.canvas.yview_moveto(0)

        if PLATFORM == 'ix':
            self.canvas.bind(MOUSE.BACK_SCROLL, self.on_mouse_wheel)
            self.canvas.bind(MOUSE.FORWARD_SCROLL, self.on_mouse_wheel)
        else:
            self.canvas.bind('<MouseWheel>', self.on_mouse_wheel)

        self._yscrollincrement = self.canvas['yscrollincrement']

    def destroy(self):
        if PLATFORM == 'ix':
            self.canvas.unbind_all(MOUSE.BACK_SCROLL)
            self.canvas.unbind_all(MOUSE.FORWARD_SCROLL)
        else:
            self.canvas.unbind_all('<MouseWheel>')
        super().destroy()

    def on_mouse_wheel(self, event):
        if PLATFORM == 'win':
            self.yview_scroll(int(-1 * (event.delta / 120)), 'units')
        elif PLATFORM == 'mac':
            self.yview_scroll(int(-1 * event.delta), 'units')
        else:
            if event.num == 4:
                self.yview_scroll(-1, 'units')
            elif event.num == 5:
                self.yview_scroll(1, 'units')

    def xview(self, *args):
        self.canvas.xview(*args)

    def yview(self, *args):
        self.canvas.yview(*args)

    def yview_scroll(self, *args):
        if self.canvas.yview() == (0.0, 1.0):
            return

        self.canvas.yview_scroll(*args)



class StatisticsFrame(ABC, ScrollFrame, SubController):
    _LBL_WIDTH = 200
    _LBL_DIST = 10
    _RIGHT_MARGIN = 40
    _LBL_HEIGHT = 20
    _BAR_HEIGHT = 10

    def __init__(self, model, view, controller, prefs, parent, *args, **kw):
        ScrollFrame.__init__(self, parent, *args, **kw)
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self.prefs = prefs
        self._HALF_BAR = self._BAR_HEIGHT / 2
        self._TEXT_COLOR = self.prefs['color_text']
        self._BG_COLOR = self.prefs['color_filler']
        self._TEXT_MAX = self._LBL_WIDTH / 5
        self.canvas['background'] = self.prefs['color_background']
        self.wordsTotal = 0

    @abstractmethod
    def draw(self):
        pass

    def _adjust_scrollbar(self):
        totalBounds = self.canvas.bbox('all')
        if totalBounds is not None:
            self.canvas.configure(scrollregion=(0, 0, 0, totalBounds[3]))

    def _get_element_id(self, event):
        return event.widget.itemcget('current', 'tag').split(' ')[0]

    def _get_win_scaling(self):
        self.update()

        x0 = self._LBL_WIDTH + self._LBL_DIST
        x3 = self.winfo_width() - self._RIGHT_MARGIN
        try:
            wcNorm = (x3 - x0) / self.wordsTotal
        except ZeroDivisionError:
            wcNorm = 0
        return wcNorm, x0, x3

    def _on_double_click(self, event):
        elementId = self._get_element_id(event)
        self._ui.tv.go_to_node(elementId)



class ChapterFrame(StatisticsFrame):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.chapterWords = {}

    def calculate(self):
        self.wordsTotal = 0
        for chId in self._mdl.tree.get_children(CH_ROOT):
            if self._mdl.novel.chapters[chId].chType == 0:
                if self._mdl.novel.chapters[chId].chLevel == 2:
                    self.chapterWords[chId] = 0
                for scId in self._mdl.tree.get_children(chId):
                    if self._mdl.novel.sections[scId].scType == 0:
                        self.chapterWords[chId] += (
                            self._mdl.novel.sections[scId].wordCount
                        )
                        self.wordsTotal += (
                            self._mdl.novel.sections[scId].wordCount
                        )

    def draw(self):
        try:
            wcNorm, x0, x3 = self._get_win_scaling()
        except:
            return

        barColor = self.prefs['color_chapter']
        y = self._LBL_HEIGHT
        self.canvas.delete("all")
        x2 = self._LBL_WIDTH + self._LBL_DIST
        for chId in self.chapterWords:
            title = textwrap.shorten(
                self._mdl.novel.chapters[chId].title,
                width=x2 / 5
            )
            y += self._LBL_HEIGHT
            x1 = x2
            y1 = y
            x2 = x1 + self.chapterWords[chId] * wcNorm
            y2 = y1 + self._BAR_HEIGHT
            self.canvas.create_rectangle(x1, y1, x2, y2, fill=barColor)
            titleLabel = self.canvas.create_text(
                (x1 - self._LBL_DIST, y + self._HALF_BAR),
                text=title,
                fill=self._TEXT_COLOR,
                anchor='e',
                tags=chId,
            )
            self.canvas.tag_bind(
                titleLabel,
                '<Double-Button-1>',
                self._on_double_click
            )
        self._adjust_scrollbar()




class PartFrame(StatisticsFrame):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.partWords = {}

    def calculate(self):
        self.wordsTotal = 0
        partId = None
        for chId in self._mdl.tree.get_children(CH_ROOT):
            if self._mdl.novel.chapters[chId].chType == 0:
                if self._mdl.novel.chapters[chId].chLevel == 1:
                    partId = chId
                    self.partWords[partId] = 0
                for scId in self._mdl.tree.get_children(chId):
                    if self._mdl.novel.sections[scId].scType == 0:
                        if partId is not None:
                            self.partWords[partId] += (
                                self._mdl.novel.sections[scId].wordCount
                            )
                        self.wordsTotal += (
                            self._mdl.novel.sections[scId].wordCount
                        )

    def draw(self):
        try:
            wcNorm, x0, x3 = self._get_win_scaling()
        except:
            return

        barColor = self.prefs['color_part']
        y = self._LBL_HEIGHT
        self.canvas.delete("all")
        x2 = self._LBL_WIDTH + self._LBL_DIST
        for chId in self.partWords:
            title = textwrap.shorten(
                self._mdl.novel.chapters[chId].title,
                width=x2 / 5
            )
            y += self._LBL_HEIGHT
            x1 = x2
            y1 = y
            x2 = x1 + self.partWords[chId] * wcNorm
            y2 = y1 + self._BAR_HEIGHT
            self.canvas.create_rectangle(x1, y1, x2, y2, fill=barColor)
            titleLabel = self.canvas.create_text(
                (x1 - self._LBL_DIST, y + self._HALF_BAR),
                text=title,
                fill=self._TEXT_COLOR,
                anchor='e',
                tags=chId,
            )
            self.canvas.tag_bind(
                titleLabel, '<Double-Button-1>', self._on_double_click
            )
        self._adjust_scrollbar()




class PlotlineFrame(StatisticsFrame):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.plotlineSections = {}

    def calculate(self):
        self.wordsTotal = 0
        for plId in self._mdl.novel.plotLines:
            self.plotlineSections[plId] = []
        for chId in self._mdl.tree.get_children(CH_ROOT):
            if self._mdl.novel.chapters[chId].chType == 0:
                for scId in self._mdl.tree.get_children(chId):
                    if self._mdl.novel.sections[scId].scType == 0:
                        for plId in self._mdl.novel.sections[scId].scPlotLines:
                            self.plotlineSections[plId].append(
                                (
                                    self.wordsTotal,
                                    self._mdl.novel.sections[scId].wordCount
                                )
                            )
                        self.wordsTotal += (
                            self._mdl.novel.sections[scId].wordCount
                        )

    def draw(self):
        try:
            wcNorm, x0, x3 = self._get_win_scaling()
        except:
            return

        barColor = self.prefs['color_plotline']
        y = self._LBL_HEIGHT
        self.canvas.delete("all")
        for plId in self.plotlineSections:
            y += self._LBL_HEIGHT
            y1 = y
            y2 = y1 + self._BAR_HEIGHT
            self.canvas.create_rectangle(x0, y1, x3, y2, fill=self._BG_COLOR)
            for position, wordCount in self.plotlineSections[plId]:
                if wordCount > 0:
                    x1 = x0 + position * wcNorm
                    x2 = x1 + wordCount * wcNorm
                    self.canvas.create_rectangle(x1, y1, x2, y2, fill=barColor)
            title = (
                f'{self._mdl.novel.plotLines[plId].shortName}'
                f' - {self._mdl.novel.plotLines[plId].title}'
            )
            title = textwrap.shorten(title, width=self._TEXT_MAX)
            titleLabel = self.canvas.create_text(
                (self._LBL_WIDTH, y + self._HALF_BAR),
                text=title,
                fill=self._TEXT_COLOR,
                anchor='e',
                tags=plId,
            )
            self.canvas.tag_bind(
                titleLabel, '<Double-Button-1>', self._on_double_click)
        self._adjust_scrollbar()




class PlotstructFrame(StatisticsFrame):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.stage1Words = {}
        self.stage2Words = {}

    def calculate(self):
        self.wordsTotal = 0
        stage1Id = None
        stage2Id = None
        for chId in self._mdl.tree.get_children(CH_ROOT):
            if self._mdl.novel.chapters[chId].chType == 0:
                for scId in self._mdl.tree.get_children(chId):
                    if self._mdl.novel.sections[scId].scType == 0:
                        if stage1Id is not None:
                            self.stage1Words[stage1Id] += (
                                self._mdl.novel.sections[scId].wordCount
                            )
                        if stage2Id is not None:
                            self.stage2Words[stage2Id] += (
                                    self._mdl.novel.sections[scId].wordCount
                                )
                        self.wordsTotal += (
                            self._mdl.novel.sections[scId].wordCount
                        )
                    elif self._mdl.novel.sections[scId].scType == 2:
                        stage1Id = scId
                        self.stage1Words[stage1Id] = 0
                    elif self._mdl.novel.sections[scId].scType == 3:
                        stage2Id = scId
                        self.stage2Words[stage2Id] = 0

    def draw(self):
        try:
            wcNorm, x0, x3 = self._get_win_scaling()
        except:
            return

        barColor = self.prefs['color_stage1']
        y = self._LBL_HEIGHT

        self.canvas.delete("all")
        heading = _('Stages (first level)')
        self.canvas.create_text(
            self._LBL_DIST,
            y,
            text=heading,
            fill=self._TEXT_COLOR,
            anchor='w',
        )
        x2 = self._LBL_WIDTH + self._LBL_DIST
        for scId in self.stage1Words:
            title = textwrap.shorten(
                self._mdl.novel.sections[scId].title,
                width=x2 / 5
            )
            y += self._LBL_HEIGHT
            x1 = x2
            y1 = y
            x2 = x1 + self.stage1Words[scId] * wcNorm
            y2 = y1 + self._BAR_HEIGHT
            self.canvas.create_rectangle(
                x1,
                y1,
                x2,
                y2,
                fill=barColor,
            )
            titleLabel = self.canvas.create_text(
                (x1 - self._LBL_DIST, y + self._HALF_BAR),
                text=title,
                fill=self._TEXT_COLOR,
                anchor='e',
                tags=scId,
            )
            self.canvas.tag_bind(
                titleLabel, '<Double-Button-1>', self._on_double_click)

        y += self._LBL_HEIGHT
        heading = _('Stages (second level)')
        self.canvas.create_text(
            self._LBL_DIST,
            y,
            text=heading,
            fill=self._TEXT_COLOR,
            anchor='w',
        )
        barColor = self.prefs['color_stage2']
        x2 = self._LBL_WIDTH + self._LBL_DIST
        for scId in self.stage2Words:
            title = textwrap.shorten(
                self._mdl.novel.sections[scId].title,
                width=x2 / 5
            )
            y += self._LBL_HEIGHT
            x1 = x2
            y1 = y
            x2 = x1 + self.stage2Words[scId] * wcNorm
            y2 = y1 + self._BAR_HEIGHT
            self.canvas.create_rectangle(
                x1,
                y1,
                x2,
                y2,
                fill=barColor,
            )
            titleLabel = self.canvas.create_text(
                (x1 - self._LBL_DIST, y + self._HALF_BAR),
                text=title,
                fill=self._TEXT_COLOR,
                anchor='e',
                tags=scId,
            )
            self.canvas.tag_bind(
                titleLabel, '<Double-Button-1>', self._on_double_click)
        self._adjust_scrollbar()



class PovFrame(StatisticsFrame):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.viewpointSections = {}

    def calculate(self):
        self.wordsTotal = 0
        for crId in self._mdl.novel.characters:
            self.viewpointSections[crId] = []
        for chId in self._mdl.tree.get_children(CH_ROOT):
            if self._mdl.novel.chapters[chId].chType == 0:
                for scId in self._mdl.tree.get_children(chId):
                    if self._mdl.novel.sections[scId].scType == 0:
                        if self._mdl.novel.sections[scId].viewpoint:
                            crId = self._mdl.novel.sections[scId].viewpoint
                            self.viewpointSections[crId].append(
                                (
                                    self.wordsTotal,
                                    self._mdl.novel.sections[scId].wordCount
                                )
                            )
                        self.wordsTotal += (
                            self._mdl.novel.sections[scId].wordCount
                        )

    def draw(self):
        try:
            wcNorm, x0, x3 = self._get_win_scaling()
        except:
            return

        barColor = self.prefs['color_viewpoint']
        y = self._LBL_HEIGHT
        self.canvas.delete("all")
        for crId in self.viewpointSections:
            if self.viewpointSections[crId]:
                y += self._LBL_HEIGHT
                y1 = y
                y2 = y1 + self._BAR_HEIGHT
                self.canvas.create_rectangle(
                    x0,
                    y1,
                    x3,
                    y2,
                    fill=self._BG_COLOR,
                )
                for position, wordCount in self.viewpointSections[crId]:
                    if wordCount > 0:
                        x1 = x0 + position * wcNorm
                        x2 = x1 + wordCount * wcNorm
                        self.canvas.create_rectangle(
                            x1,
                            y1,
                            x2,
                            y2,
                            fill=barColor,
                        )
                title = textwrap.shorten(
                    self._mdl.novel.characters[crId].title,
                    width=self._TEXT_MAX,
                )
                titleLabel = self.canvas.create_text(
                    (self._LBL_WIDTH, y + self._HALF_BAR),
                    text=title,
                    fill=self._TEXT_COLOR,
                    anchor='e',
                    tags=crId,
                )
                self.canvas.tag_bind(
                    titleLabel, '<Double-Button-1>', self._on_double_click)
        self._adjust_scrollbar()




class SectionFrame(StatisticsFrame):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.sectionWords = {}

    def calculate(self):
        self.wordsTotal = 0
        for chId in self._mdl.tree.get_children(CH_ROOT):
            if self._mdl.novel.chapters[chId].chType == 0:
                for scId in self._mdl.tree.get_children(chId):
                    if self._mdl.novel.sections[scId].scType == 0:
                        self.sectionWords[scId] = (
                            self._mdl.novel.sections[scId].wordCount
                        )
                        self.wordsTotal += (
                            self._mdl.novel.sections[scId].wordCount
                        )

    def draw(self):
        try:
            wcNorm, x0, x3 = self._get_win_scaling()
        except:
            return

        barColor = self.prefs['color_section']
        y = self._LBL_HEIGHT
        self.canvas.delete("all")
        x2 = self._LBL_WIDTH + self._LBL_DIST
        for scId in self.sectionWords:
            title = textwrap.shorten(
                self._mdl.novel.sections[scId].title,
                width=x2 / 5
            )
            y += self._LBL_HEIGHT
            x1 = x2
            y1 = y
            x2 = x1 + self.sectionWords[scId] * wcNorm
            y2 = y1 + self._BAR_HEIGHT
            self.canvas.create_rectangle(x1, y1, x2, y2, fill=barColor)
            titleLabel = self.canvas.create_text(
                (x1 - self._LBL_DIST, y + self._HALF_BAR),
                text=title,
                fill=self._TEXT_COLOR,
                anchor='e',
                tags=scId,
            )
            self.canvas.tag_bind(
                titleLabel, '<Double-Button-1>', self._on_double_click)
        self._adjust_scrollbar()



class StatisticsView(tk.Toplevel, Observer, SubController):

    def __init__(self, model, view, controller, prefs):
        tk.Toplevel.__init__(self)
        self.minsize(400, 400)
        self.prefs = prefs

        self.geometry(self.prefs['window_geometry'])
        self.lift()
        self.focus()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        if PLATFORM != 'win':
            self.bind(KEYS.QUIT_PROGRAM[0], self.on_quit)

        self.view = ttk.Notebook(self)
        self.view.enable_traversal()
        self.view.pack(fill='both', expand=True)

        self.partFrame = PartFrame(
            model,
            view,
            controller,
            prefs,
            self.view,
        )
        self.chapterFrame = ChapterFrame(
            model,
            view,
            controller,
            prefs,
            self.view,
        )
        self.sectionFrame = SectionFrame(
            model,
            view,
            controller,
            prefs,
            self.view,
        )
        self.povFrame = PovFrame(
            model,
            view,
            controller,
            prefs,
            self.view,
        )
        self.plotstructureFrame = PlotstructFrame(
            model,
            view,
            controller,
            prefs,
            self.view,
        )
        self.plotlineFrame = PlotlineFrame(
            model,
            view,
            controller,
            prefs,
            self.view,
        )

        self._frames = [
            (self.sectionFrame, _('Sections')),
            (self.chapterFrame, _('Chapters')),
            (self.partFrame, _('Parts')),
            (self.povFrame, _('Viewpoints')),
            (self.plotstructureFrame, _('Plot structure')),
            (self.plotlineFrame, _('Plot lines')),
        ]
        for frame, text in self._frames:
            self.view.add(frame, text=text)
        self.view.bind('<<NotebookTabChanged>>', self._onTabChange)
        self.activeFrame = self._frames[0][0]

        ttk.Button(
            self,
            text=_('Close'),
            command=self.on_quit,
        ).pack(anchor='e', padx=5, pady=5)

        self.redrawing = False
        self.bind('<Configure>', self.redraw)

        self._mdl = model
        self.isOpen = True
        self._mdl.add_observer(self)

    def clear_frames(self):
        for frame in self.view.winfo_children():
            for child in frame.winfo_children():
                child.destroy()

    def on_quit(self, event=None):
        self.isOpen = False
        self._mdl.delete_observer(self)
        self.prefs['window_geometry'] = self.winfo_geometry()
        self.destroy()

    def redraw(self, event=None):
        if self.redrawing:
            return

        self.redrawing = True
        self.activeFrame.draw()
        self.redrawing = False

    def refresh(self, event=None):
        self.activeFrame.calculate()
        self.activeFrame.draw()

    def _onTabChange(self, event=None):
        self.activeFrame = self._frames[self.view.index('current')][0]
        self.activeFrame.calculate()
        self.activeFrame.draw()


class StatisticsService(SubController):
    INI_FILENAME = 'statistics.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        window_geometry='510x440',
        color_plotline='deepSkyBlue',
        color_viewpoint='goldenrod1',
        color_section='greenyellow',
        color_part='aquamarine1',
        color_chapter='green',
        color_stage1='red',
        color_stage2='orange',
        color_background='black',
        color_text='white',
        color_filler='gray15',
    )
    OPTIONS = {}

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self.statisticsView = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/{self.INI_FILENAME}'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS
        )
        self.configuration.read(self.iniFile)
        self.prefs = {}
        self.prefs.update(self.configuration.settings)
        self.prefs.update(self.configuration.options)

    def on_close(self):
        self.on_quit()

    def on_quit(self):
        if self.statisticsView is not None:
            if self.statisticsView.isOpen:
                self.statisticsView.on_quit()

        for keyword in self.prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.prefs[keyword]
        self.configuration.write(self.iniFile)

    def start_viewer(self, windowTitle):
        if self.statisticsView is not None:
            if self.statisticsView.isOpen:
                if self.statisticsView.state() == 'iconic':
                    self.statisticsView.state('normal')
                self.statisticsView.lift()
                self.statisticsView.focus()
                return

        self.statisticsView = StatisticsView(
            self._mdl,
            self._ui,
            self._ctrl,
            self.prefs,
        )
        self.statisticsView.title(f'{self._mdl.novel.title} - {windowTitle}')
        set_icon(self.statisticsView, icon='statistics', default=False)


class Plugin(PluginBase):
    VERSION = '5.5.0'
    API_VERSION = '5.35'
    DESCRIPTION = 'A project statistics view'
    URL = 'https://github.com/peter88213/nv_statistics'
    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/nv_statistics'

    FEATURE = _('Project statistics view')

    def disable_menu(self):
        """Disable menu entries when no project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='disabled')
        self._stButton.config(state='disabled')

    def enable_menu(self):
        """Enable menu entries when a project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='normal')
        self._stButton.config(state='normal')

    def install(self, model, view, controller):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.statisticsService = StatisticsService(model, view, controller)
        self._icon = self._get_icon('statistics.png')

        self._ui.toolsMenu.add_command(
            label=self.FEATURE,
            image=self._icon,
            compound='left',
            command=self.start_viewer,
            state='disabled',
        )

        self._ui.helpMenu.add_command(
            label=_('Project statistics Online help'),
            image=self._icon,
            compound='left',
            command=self.open_help,
        )

        self._configure_toolbar()

    def on_close(self):
        self.statisticsService.on_close()

    def on_quit(self):
        self.statisticsService.on_quit()

    def open_help(self, event=None):
        webbrowser.open(self.HELP_URL)

    def start_viewer(self):
        self.statisticsService.start_viewer(self.FEATURE)

    def _configure_toolbar(self):

        tk.Frame(
            self._ui.toolbar.buttonBar,
            bg='light gray',
            width=1,
        ).pack(side='left', fill='y', padx=4)

        self._stButton = ttk.Button(
            self._ui.toolbar.buttonBar,
            text=self.FEATURE,
            image=self._icon,
            command=self.start_viewer,
        )
        self._stButton.pack(side='left')
        self._stButton.image = self._icon

        if not self._ctrl.get_preferences()['enable_hovertips']:
            return

        self._mdl.nvService.new_hovertip(
            self._stButton, self._stButton['text']
        )

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon
