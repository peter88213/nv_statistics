"""Project statistics view plugin for novelibre.

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_statistics
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import webbrowser

from abc import ABC, abstractmethod



class SubController:

    def initialize_controller(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self.initialize_controller(model, view, controller)

import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_statistics', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

from pathlib import Path

import tkinter as tk


def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True

from tkinter import ttk

from abc import ABC, abstractmethod


class Observer(ABC):

    @abstractmethod
    def refresh(self):
        pass
import platform



class GenericKeys:

    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')


class GenericMouse:
    pass



class MacKeys(GenericKeys):

    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')



class MacMouse(GenericMouse):
    pass


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')



class WindowsMouse(GenericMouse):
    pass



class LinuxMouse(GenericMouse):

    BACK_SCROLL = '<Button-4>'
    FORWARD_SCROLL = '<Button-5>'


if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = WindowsMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = LinuxMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse()

from tkinter import ttk



class ScrollFrame(ttk.Frame):

    def __init__(self, parent, *args, **kw):

        ttk.Frame.__init__(self, parent, *args, **kw)

        scrollY = ttk.Scrollbar(self, orient='vertical', command=self.yview)
        scrollY.pack(fill='y', side='right', expand=False)

        self.canvas = tk.Canvas(
            self,
            borderwidth=0,
            highlightthickness=0
            )
        self.canvas.configure(yscrollcommand=scrollY.set)
        self.canvas.pack(
            anchor='n',
            fill='both',
            expand=True
            )
        self.canvas.xview_moveto(0)
        self.canvas.yview_moveto(0)

        if PLATFORM == 'ix':
            self.canvas.bind(MOUSE.BACK_SCROLL, self.on_mouse_wheel)
            self.canvas.bind(MOUSE.FORWARD_SCROLL, self.on_mouse_wheel)
        else:
            self.canvas.bind('<MouseWheel>', self.on_mouse_wheel)

        self._yscrollincrement = self.canvas['yscrollincrement']

    def destroy(self):
        if PLATFORM == 'ix':
            self.canvas.unbind_all(MOUSE.BACK_SCROLL)
            self.canvas.unbind_all(MOUSE.FORWARD_SCROLL)
        else:
            self.canvas.unbind_all('<MouseWheel>')
        super().destroy()

    def on_mouse_wheel(self, event):
        if PLATFORM == 'win':
            self.yview_scroll(int(-1 * (event.delta / 120)), 'units')
        elif PLATFORM == 'mac':
            self.yview_scroll(int(-1 * event.delta), 'units')
        else:
            if event.num == 4:
                self.yview_scroll(-1, 'units')
            elif event.num == 5:
                self.yview_scroll(1, 'units')

    def xview(self, *args):
        self.canvas.xview(*args)

    def yview(self, *args):
        self.canvas.yview(*args)

    def yview_scroll(self, *args):
        if self.canvas.yview() == (0.0, 1.0):
            return

        self.canvas.yview_scroll(*args)

import textwrap

from datetime import date
from datetime import time

ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


class Notification(Error):
    pass


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_date(dateStr):
    if dateStr is not None:
        date.fromisoformat(dateStr)
    return dateStr


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


def verified_time(timeStr):
    if  timeStr is not None:
        time.fromisoformat(timeStr)
        while timeStr.count(':') < 2:
            timeStr = f'{timeStr}:00'
    return timeStr



class StatisticsViewCtrl(SubController):

    def initialize_controller(self, model, view, controller):
        super().initialize_controller(model, view, controller)
        self.isOpen = True
        self.calculate_statistics()

    def calculate_statistics(self):
        if self._mdl.prjFile is None:
            return

        wordsTotal = 0
        partWords = {}
        chapterWords = {}
        sectionWords = {}
        stage1Words = {}
        stage2Words = {}
        plotlineWords = {}
        viewpointWords = {}
        for plId in self._mdl.novel.plotLines:
            plotlineWords[plId] = 0
        for crId in self._mdl.novel.characters:
            viewpointWords[crId] = 0
        partId = None
        stage1Id = None
        stage2Id = None
        for chId in self._mdl.tree.get_children(CH_ROOT):
            if self._mdl.novel.chapters[chId].chType == 0:
                if self._mdl.novel.chapters[chId].chLevel == 1:
                    partId = chId
                    partWords[partId] = 0
                else:
                    chapterWords[chId] = 0
                for scId in self._mdl.tree.get_children(chId):
                    if self._mdl.novel.sections[scId].scType == 0:
                        sectionWords[scId] = self._mdl.novel.sections[scId].wordCount
                        chapterWords[chId] += self._mdl.novel.sections[scId].wordCount
                        wordsTotal += self._mdl.novel.sections[scId].wordCount
                        if partId is not None:
                            partWords[partId] += self._mdl.novel.sections[scId].wordCount
                        if stage1Id is not None:
                            stage1Words[stage1Id] += self._mdl.novel.sections[scId].wordCount
                        if stage2Id is not None:
                            stage2Words[stage2Id] += self._mdl.novel.sections[scId].wordCount
                        for plId in self._mdl.novel.sections[scId].scPlotLines:
                            plotlineWords[plId] += self._mdl.novel.sections[scId].wordCount
                        if self._mdl.novel.sections[scId].characters:
                            crId = self._mdl.novel.sections[scId].characters[0]
                            viewpointWords[crId] += self._mdl.novel.sections[scId].wordCount
                    elif self._mdl.novel.sections[scId].scType == 2:
                        stage1Id = scId
                        stage1Words[stage1Id] = 0
                    elif self._mdl.novel.sections[scId].scType == 3:
                        stage2Id = scId
                        stage2Words[stage2Id] = 0

        LBL_WIDTH = 200
        LBL_DIST = 10
        RIGHT_MARGIN = 40
        LBL_HEIGHT = 20
        BAR_HEIGHT = 10
        HALF_BAR = BAR_HEIGHT / 2
        TEXT_COLOR = self.prefs['color_text']
        BG_COLOR = self.prefs['color_filler']
        TEXT_MAX = LBL_WIDTH / 5

        self.update()
        try:
            xMax = self.view.winfo_width()
        except:
            return

        xSpan = xMax - LBL_WIDTH - RIGHT_MARGIN
        x3 = xMax - RIGHT_MARGIN

        canvas = self.partCanvas
        barColor = self.prefs['color_part']
        y = LBL_HEIGHT
        canvas.delete("all")
        x2 = LBL_WIDTH + LBL_DIST
        for chId in partWords:
            title = textwrap.shorten(self._mdl.novel.chapters[chId].title, width=x2 / 5)
            percentage = partWords[chId] / wordsTotal * xSpan
            y += LBL_HEIGHT
            x1 = x2
            y1 = y
            x2 = x1 + int(percentage)
            y2 = y1 + BAR_HEIGHT
            canvas.create_rectangle(x1, y1, x2, y2, fill=barColor)
            titleLabel = canvas.create_text((x1 - LBL_DIST, y + HALF_BAR), text=title, fill=TEXT_COLOR, anchor='e', tags=chId)
            canvas.tag_bind(titleLabel, '<Double-Button-1>', self._on_double_click)
        totalBounds = canvas.bbox('all')
        if totalBounds is not None:
            canvas.configure(scrollregion=(0, 0, 0, totalBounds[3]))

        canvas = self.chapterCanvas
        barColor = self.prefs['color_chapter']
        y = LBL_HEIGHT
        canvas.delete("all")
        x2 = LBL_WIDTH + LBL_DIST
        for chId in chapterWords:
            title = textwrap.shorten(self._mdl.novel.chapters[chId].title, width=x2 / 5)
            percentage = chapterWords[chId] / wordsTotal * xSpan
            y += LBL_HEIGHT
            x1 = x2
            y1 = y
            x2 = x1 + int(percentage)
            y2 = y1 + BAR_HEIGHT
            canvas.create_rectangle(x1, y1, x2, y2, fill=barColor)
            titleLabel = canvas.create_text((x1 - LBL_DIST, y + HALF_BAR), text=title, fill=TEXT_COLOR, anchor='e', tags=chId)
            canvas.tag_bind(titleLabel, '<Double-Button-1>', self._on_double_click)
        totalBounds = canvas.bbox('all')
        if totalBounds is not None:
            canvas.configure(scrollregion=(0, 0, 0, totalBounds[3]))

        canvas = self.sectionCanvas
        barColor = self.prefs['color_section']
        y = LBL_HEIGHT
        canvas.delete("all")
        x2 = LBL_WIDTH + LBL_DIST
        for scId in sectionWords:
            title = textwrap.shorten(self._mdl.novel.sections[scId].title, width=x2 / 5)
            percentage = sectionWords[scId] / wordsTotal * xSpan
            y += LBL_HEIGHT
            x1 = x2
            y1 = y
            x2 = x1 + int(percentage)
            y2 = y1 + BAR_HEIGHT
            canvas.create_rectangle(x1, y1, x2, y2, fill=barColor)
            titleLabel = canvas.create_text((x1 - LBL_DIST, y + HALF_BAR), text=title, fill=TEXT_COLOR, anchor='e', tags=scId)
            canvas.tag_bind(titleLabel, '<Double-Button-1>', self._on_double_click)
        totalBounds = canvas.bbox('all')
        if totalBounds is not None:
            canvas.configure(scrollregion=(0, 0, 0, totalBounds[3]))

        canvas = self.povCanvas
        barColor = self.prefs['color_viewpoint']
        y = LBL_HEIGHT
        canvas.delete("all")
        for crId in viewpointWords:
            if viewpointWords[crId] == 0:
                continue

            title = textwrap.shorten(self._mdl.novel.characters[crId].title, width=TEXT_MAX)
            percentage = viewpointWords[crId] / wordsTotal * xSpan
            y += LBL_HEIGHT
            x1 = LBL_WIDTH + LBL_DIST
            y1 = y
            x2 = x1 + int(percentage)
            y2 = y1 + BAR_HEIGHT
            canvas.create_rectangle(x1, y1, x2, y2, fill=barColor)
            canvas.create_rectangle(x2, y1, x3, y2, fill=BG_COLOR)
            titleLabel = canvas.create_text((LBL_WIDTH, y + HALF_BAR), text=title, fill=TEXT_COLOR, anchor='e', tags=crId)
            canvas.tag_bind(titleLabel, '<Double-Button-1>', self._on_double_click)
        totalBounds = canvas.bbox('all')
        if totalBounds is not None:
            canvas.configure(scrollregion=(0, 0, 0, totalBounds[3]))

        canvas = self.plotstructureCanvas
        barColor = self.prefs['color_stage1']
        y = LBL_HEIGHT

        canvas.delete("all")
        heading = _('Stages (first level)')
        canvas.create_text(LBL_DIST, y, text=heading, fill=TEXT_COLOR, anchor='w')
        x2 = LBL_WIDTH + LBL_DIST
        for scId in stage1Words:
            title = textwrap.shorten(self._mdl.novel.sections[scId].title, width=x2 / 5)
            percentage = stage1Words[scId] / wordsTotal * xSpan
            y += LBL_HEIGHT
            x1 = x2
            y1 = y
            x2 = x1 + int(percentage)
            y2 = y1 + BAR_HEIGHT
            canvas.create_rectangle(x1, y1, x2, y2, fill=barColor)
            titleLabel = canvas.create_text((x1 - LBL_DIST, y + HALF_BAR), text=title, fill=TEXT_COLOR, anchor='e', tags=scId)
            canvas.tag_bind(titleLabel, '<Double-Button-1>', self._on_double_click)

        y += LBL_HEIGHT
        heading = _('Stages (second level)')
        canvas.create_text(LBL_DIST, y, text=heading, fill=TEXT_COLOR, anchor='w')
        barColor = self.prefs['color_stage2']
        x2 = LBL_WIDTH + LBL_DIST
        for scId in stage2Words:
            title = textwrap.shorten(self._mdl.novel.sections[scId].title, width=x2 / 5)
            percentage = stage2Words[scId] / wordsTotal * xSpan
            y += LBL_HEIGHT
            x1 = x2
            y1 = y
            x2 = x1 + int(percentage)
            y2 = y1 + BAR_HEIGHT
            canvas.create_rectangle(x1, y1, x2, y2, fill=barColor)
            titleLabel = canvas.create_text((x1 - LBL_DIST, y + HALF_BAR), text=title, fill=TEXT_COLOR, anchor='e', tags=scId)
            canvas.tag_bind(titleLabel, '<Double-Button-1>', self._on_double_click)
        totalBounds = canvas.bbox('all')
        if totalBounds is not None:
            canvas.configure(scrollregion=(0, 0, 0, totalBounds[3]))

        canvas = self.plotlineCanvas
        barColor = self.prefs['color_plotline']
        y = LBL_HEIGHT
        canvas.delete("all")
        for plId in plotlineWords:
            title = f'{self._mdl.novel.plotLines[plId].shortName} - {self._mdl.novel.plotLines[plId].title}'
            title = textwrap.shorten(title, width=TEXT_MAX)
            percentage = plotlineWords[plId] / wordsTotal * xSpan
            y += LBL_HEIGHT
            x1 = LBL_WIDTH + LBL_DIST
            y1 = y
            x2 = x1 + int(percentage)
            y2 = y1 + BAR_HEIGHT
            canvas.create_rectangle(x1, y1, x2, y2, fill=barColor)
            canvas.create_rectangle(x2, y1, x3, y2, fill=BG_COLOR)
            titleLabel = canvas.create_text((LBL_WIDTH, y + HALF_BAR), text=title, fill=TEXT_COLOR, anchor='e', tags=plId)
            canvas.tag_bind(titleLabel, '<Double-Button-1>', self._on_double_click)
        totalBounds = canvas.bbox('all')
        if totalBounds is not None:
            canvas.configure(scrollregion=(0, 0, 0, totalBounds[3]))

    def _get_element_id(self, event):
        return event.widget.itemcget('current', 'tag').split(' ')[0]

    def _on_double_click(self, event):
        elementId = self._get_element_id(event)
        self._ui.tv.go_to_node(elementId)



class StatisticsView(tk.Toplevel, Observer, StatisticsViewCtrl):

    def __init__(self, model, view, controller, prefs):
        tk.Toplevel.__init__(self)
        self.prefs = prefs

        self.geometry(self.prefs['window_geometry'])
        self.lift()
        self.focus()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        if PLATFORM != 'win':
            self.bind(KEYS.QUIT_PROGRAM[0], self.on_quit)

        self.view = ttk.Notebook(self)
        self.view.enable_traversal()
        self.view.pack(fill='both', expand=True)

        self.partFrame = ScrollFrame(self.view)
        self.chapterFrame = ScrollFrame(self.view)
        self.sectionFrame = ScrollFrame(self.view)
        self.povFrame = ScrollFrame(self.view)
        self.plotstructureFrame = ScrollFrame(self.view)
        self.plotlineFrame = ScrollFrame(self.view)

        self.view.add(self.sectionFrame, text=_('Sections'))
        self.view.add(self.chapterFrame, text=_('Chapters'))
        self.view.add(self.partFrame, text=_('Parts'))
        self.view.add(self.povFrame, text=_('Viewpoints'))
        self.view.add(self.plotstructureFrame, text=_('Plot structure'))
        self.view.add(self.plotlineFrame, text=_('Plot lines'))

        self.partCanvas = self.partFrame.canvas
        self.partCanvas['background'] = self.prefs['color_background']

        self.chapterCanvas = self.chapterFrame.canvas
        self.chapterCanvas['background'] = self.prefs['color_background']

        self.sectionCanvas = self.sectionFrame.canvas
        self.sectionCanvas['background'] = self.prefs['color_background']

        self.povCanvas = self.povFrame.canvas
        self.povCanvas['background'] = self.prefs['color_background']

        self.plotstructureCanvas = self.plotstructureFrame.canvas
        self.plotstructureCanvas['background'] = self.prefs['color_background']

        self.plotlineCanvas = self.plotlineFrame.canvas
        self.plotlineCanvas['background'] = self.prefs['color_background']

        ttk.Button(self, text=_('Close'), command=self.on_quit).pack(anchor='e', padx=5, pady=5)

        self.bind('<Configure>', self.refresh)

        self.initialize_controller(model, view, controller)
        self._mdl.add_observer(self)

    def clear_frames(self):
        for frame in self.view.winfo_children():
            for child in frame.winfo_children():
                child.destroy()

    def on_quit(self, event=None):
        self.isOpen = False
        self._mdl.delete_observer(self)
        self.prefs['window_geometry'] = self.winfo_geometry()
        self.destroy()

    def refresh(self, event=None):
        self.calculate_statistics()



class StatisticsService(SubController):
    INI_FILENAME = 'statistics.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        window_geometry='510x440',
        color_plotline='deepSkyBlue',
        color_viewpoint='goldenrod1',
        color_section='coral1',
        color_part='aquamarine1',
        color_chapter='green',
        color_stage1='red',
        color_stage2='orange',
        color_background='black',
        color_text='white',
        color_filler='gray15',
    )
    OPTIONS = {}

    def __init__(self, model, view, controller):
        super().initialize_controller(model, view, controller)
        self.statisticsView = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/{self.INI_FILENAME}'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS
            )
        self.configuration.read(self.iniFile)
        self.prefs = {}
        self.prefs.update(self.configuration.settings)
        self.prefs.update(self.configuration.options)

    def on_close(self):
        self.on_quit()

    def on_quit(self):
        if self.statisticsView is not None:
            if self.statisticsView.isOpen:
                self.statisticsView.on_quit()

        for keyword in self.prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.prefs[keyword]
        self.configuration.write(self.iniFile)

    def start_viewer(self, windowTitle):
        if self.statisticsView is not None:
            if self.statisticsView.isOpen:
                if self.statisticsView.state() == 'iconic':
                    self.statisticsView.state('normal')
                self.statisticsView.lift()
                self.statisticsView.focus()
                return

        self.statisticsView = StatisticsView(self._mdl, self._ui, self._ctrl, self.prefs)
        self.statisticsView.title(f'{self._mdl.novel.title} - {windowTitle}')
        set_icon(self.statisticsView, icon='sLogo32', default=False)


class Plugin(PluginBase):
    VERSION = '5.0.0'
    API_VERSION = '5.0'
    DESCRIPTION = 'A project statistics view'
    URL = 'https://github.com/peter88213/nv_statistics'
    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/nv_statistics'

    FEATURE = _('Project statistics view')

    def disable_menu(self):
        """Disable menu entries when no project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='disabled')

    def enable_menu(self):
        """Enable menu entries when a project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='normal')

    def install(self, model, view, controller):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Optional arguments:
            prefs -- deprecated. Please use controller.get_preferences() instead.
        
        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.statisticsService = StatisticsService(model, view, controller)

        self._ui.helpMenu.add_command(label=_('Project statistics Online help'), command=self.open_help)

        self._ui.toolsMenu.add_command(label=self.FEATURE, command=self.start_viewer)
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='disabled')

    def on_close(self):
        self.statisticsService.on_close()

    def on_quit(self):
        self.statisticsService.on_quit()

    def open_help(self, event=None):
        webbrowser.open(self.HELP_URL)

    def start_viewer(self):
        self.statisticsService.start_viewer(self.FEATURE)
